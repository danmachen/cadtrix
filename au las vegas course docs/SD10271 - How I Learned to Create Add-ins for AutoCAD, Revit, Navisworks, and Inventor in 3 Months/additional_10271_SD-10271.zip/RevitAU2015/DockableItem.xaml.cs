﻿using System.Windows;
using System.Windows.Controls;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Events;
using System;

namespace RevitAU2015
{
    /// <summary>
    /// Interaction logic for DockableItem.xaml
    /// </summary>
    public partial class DockableItem : UserControl, IDockablePaneProvider
    {
        public DockableItem()
        {
            InitializeComponent();
            SharedAU2015.Class1.SetupDockableItem(CityList, WeatherText);
        }

        public void SetupDockablePane(DockablePaneProviderData data)
        {
            data.FrameworkElement = this as FrameworkElement;
            data.InitialState = new DockablePaneState();
            data.InitialState.DockPosition = DockPosition.Tabbed;
            data.InitialState.TabBehind = DockablePanes.BuiltInDockablePanes.PropertiesPalette;
        }

        private void CityList_DropDownClosed(object sender, System.EventArgs e)
        {
            SharedAU2015.Class1.CityList_SelectionChanged(sender, WeatherText);
        }

        private void ActivateButton_Click(object sender, RoutedEventArgs e)
        {
            this.HandlerText.Text = "Try creating a wall, and see what happens to this text";
        }
    }
}
