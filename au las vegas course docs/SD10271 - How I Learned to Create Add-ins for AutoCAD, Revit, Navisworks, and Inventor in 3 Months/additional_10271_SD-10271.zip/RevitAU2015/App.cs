﻿using Autodesk.Revit.UI;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System;

namespace RevitAU2015
{
    class App : IExternalApplication
    {
        public static DockableItem m_RevitDockableWindow = null;
        public static DockablePaneId dpid = null;
        public static UIApplication uiapp = null;
        public static AddInCommandBinding importBindingID_OBJECTS_WALL = null;
        public Result OnShutdown(UIControlledApplication application)
        {
            return Result.Succeeded;
        }

        public Result OnStartup(UIControlledApplication application)
        {
            //Add a Panel to the Ribbon
            RibbonPanel AU2015Ribbon = application.CreateRibbonPanel("AU2015");
            AU2015Ribbon.Enabled = true;
            AU2015Ribbon.Visible = true;
            //Add a Button to the Ribbon
            string assembly = System.Reflection.Assembly.GetExecutingAssembly().Location;
            PushButton AU2015Button = AU2015Ribbon.AddItem(new PushButtonData("AU2015", "AU2015", assembly, typeof(LoadDockableItem).FullName)) as PushButton;
            AU2015Button.ToolTipImage = new BitmapImage(new Uri("http://redtopsoftware.blob.core.windows.net/imageresources/Check.png", UriKind.Absolute));
            AU2015Button.ToolTip = "This probably runs something";
            AU2015Button.SetContextualHelp(new ContextualHelp(ContextualHelpType.Url, "C:\\ProgramData\\Autodesk\\ApplicationPlugins\\AU2015.bundle\\Contents\\Help.htm"));
            //Set up the DockableItem
            DockablePaneProviderData data = new DockablePaneProviderData();
            DockableItem RevitDockableWindow = new DockableItem();
            m_RevitDockableWindow = RevitDockableWindow;
            data.FrameworkElement = RevitDockableWindow as System.Windows.FrameworkElement;
            data.InitialState = new DockablePaneState();
            data.InitialState.DockPosition = DockPosition.Tabbed;
            data.InitialState.TabBehind = DockablePanes.BuiltInDockablePanes.PropertiesPalette;
            dpid = new DockablePaneId(new Guid("{43456832-2780-42c9-88b1-905950c96757}"));
            application.RegisterDockablePane(dpid, "AU2015", RevitDockableWindow as IDockablePaneProvider);
            //Handler Setup
            importBindingID_OBJECTS_WALL = application.CreateAddInCommandBinding(RevitCommandId.LookupCommandId("ID_OBJECTS_WALL"));
            try
            {
                App.importBindingID_OBJECTS_WALL.BeforeExecuted += new EventHandler<Autodesk.Revit.UI.Events.BeforeExecutedEventArgs>((sender, arg) => UpdateDockablePane(sender, arg, "ID_OBJECTS_WALL"));
            }
            catch
            {
                MessageBox.Show("Whoops, that broke it");
            }
            return Result.Succeeded;
        }
        public void UpdateDockablePane(object sender, EventArgs e, String RevitInternalName)
        {
            App.m_RevitDockableWindow.HandlerText.Text = "You just ran the command WALL nice work!";
        }
    }
}
