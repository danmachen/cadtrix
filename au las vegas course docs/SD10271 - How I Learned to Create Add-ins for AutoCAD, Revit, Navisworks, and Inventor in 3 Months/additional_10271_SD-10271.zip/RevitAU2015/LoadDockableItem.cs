﻿using Autodesk.Revit.Attributes;
using Autodesk.Revit.UI;
using System;
using System.Collections.Generic;
using Autodesk.Revit.DB;

namespace RevitAU2015
{
    [Transaction(TransactionMode.Manual)]
    class LoadDockableItem : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            DockablePane dp = commandData.Application.GetDockablePane(App.dpid);
            RevitAU2015.App.uiapp = commandData.Application;
            //Get Data From Weather Underground
            dp.Show();
            return Result.Succeeded;
        }
    }
}
