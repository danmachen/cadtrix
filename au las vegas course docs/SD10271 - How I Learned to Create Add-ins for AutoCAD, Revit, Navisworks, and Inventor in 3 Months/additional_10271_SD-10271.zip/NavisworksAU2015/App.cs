﻿using Autodesk.Navisworks.Api.Plugins;
using System.Windows.Forms;

namespace NavisworksAU2015
{
    [Plugin("NavisworksAU2015.App", "NNAW", ToolTip = "Plugin", DisplayName = "Plugin")]
    //[AddInPlugin(AddInLocation.AddIn, CanToggle = true, LoadForCanExecute = true, CallCanExecute = CallCanExecute.Always, )]
    public class App : AddInPlugin
    {
        public override int Execute(params string[] parameters)
        {
            MessageBox.Show("Hello Autodesk University");
            //Setup Dockable Window
            PluginRecord pr = Autodesk.Navisworks.Api.Application.Plugins.FindPlugin("NavisworksAU2015.PlugIn.NNAW");
            if(pr != null && pr is DockPanePluginRecord && pr.IsEnabled)
            {
                if(pr.LoadedPlugin == null)
                {
                    pr.LoadPlugin();
                }
                DockPanePlugin dpp = pr.LoadedPlugin as DockPanePlugin;
                if(dpp != null)
                {
                    dpp.Visible = !dpp.Visible;
                }
            }
            return 0;
        }
    }
}
