﻿using Autodesk.Navisworks.Api.Plugins;
using System.Windows.Forms;
using System.Windows.Forms.Integration;
using System;

namespace NavisworksAU2015
{
    [Plugin("NavisworksAU2015.PlugIn", "NNAW", ToolTip = "Plugin", DisplayName = "Plugin")]
    [DockPanePlugin(150, 200, FixedSize = false)]
    class PlugIn : DockPanePlugin
    {

        public override Control CreateControlPane()
        {
            DockableItem uc = new DockableItem();
            ElementHost eh = new ElementHost();
            eh.AutoSize = true;
            eh.Child = uc;
            eh.CreateControl();
            return eh;
        }
    }
}
