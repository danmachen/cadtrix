﻿using System.Windows.Controls;

using System.Collections.Generic;
using Autodesk.AutoCAD.ApplicationServices;
using System.Windows.Forms;

namespace AutoCADAU2015
{
    /// <summary>
    /// Interaction logic for DockableItem.xaml
    /// </summary>
    public partial class DockableItem : System.Windows.Controls.UserControl
    {
        public DockableItem()
        {
            InitializeComponent();
            SharedAU2015.Class1.SetupDockableItem(CityList, WeatherText);
        }



        private void CityList_DropDownClosed(object sender, System.EventArgs e)
        {
            SharedAU2015.Class1.CityList_SelectionChanged(sender, WeatherText);
        }
        private void ActivateButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            System.Windows.Controls.Button but = (System.Windows.Controls.Button)sender;
            if (but.Content.ToString() == "Activate Handler")
            {
                Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.CommandWillStart += new CommandEventHandler(CommandBeginHandler);
                but.Content = "Deactivate Handler";
            }
            else
            {
                Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.CommandWillStart -= new CommandEventHandler(CommandBeginHandler);
                but.Content = "Activate Handler";
            }

        }
        public void CommandBeginHandler(object sender, CommandEventArgs e)
        {
            HandlerText.Text = "You just ran the command " + e.GlobalCommandName + " nice work!";
        }
    }
}
