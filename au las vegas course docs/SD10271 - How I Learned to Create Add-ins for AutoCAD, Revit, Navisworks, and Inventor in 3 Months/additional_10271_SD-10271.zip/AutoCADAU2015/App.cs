﻿using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Windows;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AutoCADAU2015
{
    public class App
    {
        [CommandMethod("AU2015GROUP", "AU2015", CommandFlags.NoActionRecording)]
        public void AU2015()
        {
            MessageBox.Show("Hello Autodesk University");
            PaletteSet ps = null;
            if (ps == null)
            {
                DockableItem AutoCADDockableWindow = new DockableItem();
                ps = new PaletteSet("AU2015");
                ps.Size = new System.Drawing.Size(400, 600);
                ps.DockEnabled = (DockSides)((int)DockSides.Left + (int)DockSides.Right);
                ps.Style = PaletteSetStyles.ShowAutoHideButton;
                ps.AddVisual("AddVisual", AutoCADDockableWindow);
                ps.KeepFocus = true;
                ps.Visible = true;
            }
        }
    }
}
