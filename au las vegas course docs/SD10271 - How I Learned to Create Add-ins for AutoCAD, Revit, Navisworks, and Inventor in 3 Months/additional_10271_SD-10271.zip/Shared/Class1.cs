﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace SharedAU2015
{
    public class Class1
    {
        public static void CityList_SelectionChanged(object sender, TextBlock lbl)
        {
            List<string> weatherdata = null;
            System.Windows.Controls.ComboBox cbo = (System.Windows.Controls.ComboBox)sender;
            if (cbo.Text == "Las Vegas")
            {
                weatherdata = Weather.RequestData("http://api.wunderground.com/api/5751aba181ba964f/conditions/q/NV/Las%20Vegas.xml");
            }
            if (cbo.Text == "New York")
            {
                weatherdata = Weather.RequestData("http://api.wunderground.com/api/5751aba181ba964f/conditions/q/NY/New%20York.xml");
            }
            if (cbo.Text == "Toronto")
            {
                weatherdata = Weather.RequestData("http://api.wunderground.com/api/5751aba181ba964f/conditions/q/Canada/Toronto.xml");
            }
            if (cbo.Text == "Vancouver")
            {
                weatherdata = Weather.RequestData("http://api.wunderground.com/api/5751aba181ba964f/conditions/q/Canada/Vancouver.xml");
            }
            if (weatherdata != null)
            {
                lbl.Text = "The temperature @ " + weatherdata[0] + " is currently " + weatherdata[3];
            }
            else
            {
                MessageBox.Show("No weather Data Found");
            }

        }
        public static void SetupDockableItem(ComboBox cbo, TextBlock lbl)
        {
            List<string> weatherdata = Weather.RequestData("http://api.wunderground.com/api/5751aba181ba964f/conditions/q/Canada/Vancouver.xml");
            string CurrentTemp = weatherdata[3];            
            lbl.Text = "The temperature @ Vancouver is currently " + CurrentTemp;
            cbo.ItemsSource = new List<string> { "Vancouver", "Las Vegas", "New York", "Toronto" };
        }
    }
}
