﻿using System;
using System.Xml;
using System.Net;
using System.IO;
using System.Collections.Generic;

namespace SharedAU2015
{
    public class Weather
    {
        //Takes a url request to wunderground, parses it, and displays the data.
        public static List<string> RequestData(string input_xml)
        {
            //Variables
            List<string> WeatherData = new List<string>();
            string place = "";
            string obs_time = "";
            string weather1 = "";
            string temperature_string = "";
            string relative_humidity = "";
            string wind_string = "";
            string pressure_mb = "";
            string dewpoint_string = "";
            string visibility_km = "";
            string latitude = "";
            string longitude = "";
            var cli = new WebClient();
            string weather = cli.DownloadString(input_xml);
            using (XmlReader reader = XmlReader.Create(new StringReader(weather)))
            {
                // Parse the file and display each of the nodes.
                while (reader.Read())
                {
                    switch (reader.NodeType)
                    {
                        case XmlNodeType.Element:
                            if (reader.Name.Equals("full"))
                            {
                                reader.Read();
                                place = reader.Value;
                            }
                            else if (reader.Name.Equals("observation_time"))
                            {
                                reader.Read();
                                obs_time = reader.Value;
                            }
                            else if (reader.Name.Equals("weather"))
                            {
                                reader.Read();
                                weather1 = reader.Value;
                            }
                            else if (reader.Name.Equals("temperature_string"))
                            {
                                reader.Read();
                                temperature_string = reader.Value;
                            }
                            else if (reader.Name.Equals("relative_humidity"))
                            {
                                reader.Read();
                                relative_humidity = reader.Value;
                            }
                            else if (reader.Name.Equals("wind_string"))
                            {
                                reader.Read();
                                wind_string = reader.Value;
                            }
                            else if (reader.Name.Equals("pressure_mb"))
                            {
                                reader.Read();
                                pressure_mb = reader.Value;
                            }
                            else if (reader.Name.Equals("dewpoint_string"))
                            {
                                reader.Read();
                                dewpoint_string = reader.Value;
                            }
                            else if (reader.Name.Equals("visibility_km"))
                            {
                                reader.Read();
                                visibility_km = reader.Value;
                            }
                            else if (reader.Name.Equals("latitude"))
                            {
                                reader.Read();
                                latitude = reader.Value;
                            }
                            else if (reader.Name.Equals("longitude"))
                            {
                                reader.Read();
                                longitude = reader.Value;
                            }
                            break;
                    }
                }
            }
            WeatherData.Add(place);
            WeatherData.Add(obs_time);
            WeatherData.Add(weather1);
            WeatherData.Add(temperature_string);
            WeatherData.Add(relative_humidity);
            WeatherData.Add(wind_string);
            WeatherData.Add(pressure_mb);
            WeatherData.Add(dewpoint_string);
            WeatherData.Add(visibility_km);
            WeatherData.Add(latitude);
            WeatherData.Add(longitude);
            return WeatherData;
        }
        //
        //
        //
        public static List<string> RequestCities(string input_xml)
        {
            //Variables
            List<string> CanadaCityList = new List<string>();
            string place = "";            
            var cli = new WebClient();
            string weather = cli.DownloadString(input_xml);
            using (XmlReader reader = XmlReader.Create(new StringReader(weather)))
            {
                // Parse the file and display each of the nodes.
                while (reader.Read())
                {
                    switch (reader.NodeType)
                    {
                        case XmlNodeType.Element:
                            if (reader.Name.Equals("City"))
                            {
                                reader.Read();
                                place = reader.Value;
                            }                            
                            break;
                    }
                }
            }
            CanadaCityList.Add(place);
            
            return CanadaCityList;
        }
    }
}



