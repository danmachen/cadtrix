﻿
using System;
using System.Windows.Controls;

namespace InventorAU2015
{
    /// <summary>
    /// Interaction logic for DockableItem.xaml
    /// </summary>
    public partial class DockableItem : UserControl
    {
        public DockableItem()
        {
            InitializeComponent();
            SharedAU2015.Class1.SetupDockableItem(CityList, WeatherText);
        }



        private void CityList_DropDownClosed(object sender, System.EventArgs e)
        {
            SharedAU2015.Class1.CityList_SelectionChanged(sender, WeatherText);
        }
        private void ActivateButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            System.Windows.Controls.Button but = (System.Windows.Controls.Button)sender;
            if (but.Content.ToString() == "Activate Handler")
            {
                //Setup Event Handler
                Autodesk.Windows.ComponentManager.ItemExecuted += new EventHandler<Autodesk.Internal.Windows.RibbonItemExecutedEventArgs>(ItemExecutedTest);
                but.Content = "Deactivate Handler";
            }
            else
            {
                //Setup Event Handler
                Autodesk.Windows.ComponentManager.ItemExecuted -= new EventHandler<Autodesk.Internal.Windows.RibbonItemExecutedEventArgs>(ItemExecutedTest);
                but.Content = "Activate Handler";
            }
        }
        void ItemExecutedTest(object sender, Autodesk.Internal.Windows.RibbonItemExecutedEventArgs e)
        {
            HandlerText.Text = "You just ran the command " + e.Item.Text.ToString() + " nice work!";
        }
    }
}
