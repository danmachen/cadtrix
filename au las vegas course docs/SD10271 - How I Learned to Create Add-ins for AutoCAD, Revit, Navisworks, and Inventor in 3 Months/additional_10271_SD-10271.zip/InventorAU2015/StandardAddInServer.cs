﻿using System;
using System.Runtime.InteropServices;
using Inventor;
using System.Windows.Forms;

namespace InventorAU2015
{
    [Guid("e6d53d6c-442f-4979-a4ae-26916f1c59a0"), ComVisible(true)]
    public class StandardAddInServer : Inventor.ApplicationAddInServer
    {
        public static DockableItem bc = null;
        public StandardAddInServer()
        {
        }
        public void Activate(ApplicationAddInSite AddInSiteObject, bool FirstTime)
        {
            MessageBox.Show("Hello Autodesk University");
            //Setup Dockable Window
            Inventor.Application inventorApplication = AddInSiteObject.Application;
            UserInterfaceManager uiMan = inventorApplication.UserInterfaceManager;
            DockableWindow docableWin = uiMan.DockableWindows.Add(Guid.NewGuid().ToString(), "INAW_UIMiscs_DockableWindow1", "AU2015");
            docableWin.AddChild(CreateChildDialog());
            docableWin.DisabledDockingStates = DockingStateEnum.kDockLeft | DockingStateEnum.kDockTop;
            docableWin.DockingState = DockingStateEnum.kDockRight;
            docableWin.ShowVisibilityCheckBox = true;
            docableWin.ShowTitleBar = true;
            docableWin.SetMinimumSize(100, 100);
            docableWin.Visible = true;

        }
        public static long CreateChildDialog()
        {
            System.Windows.Forms.Integration.ElementHost host = new System.Windows.Forms.Integration.ElementHost();
            host.Dock = DockStyle.Fill;
            bc = new DockableItem();
            Form dc = new Form();
            host.Child = bc;
            dc.Controls.Add(host);
            dc.FormBorderStyle = FormBorderStyle.None;
            dc.HelpButton = dc.MinimizeBox = dc.MaximizeBox = false;
            dc.ShowIcon = dc.ShowInTaskbar = false;
            dc.TopMost = true;
            dc.Height = 100;
            dc.Width = 300;
            dc.MinimumSize = new System.Drawing.Size(dc.Width, dc.Height);
            dc.Show();
            return dc.Handle.ToInt64();
        }
        public dynamic Automation
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public void Deactivate()
        {
            throw new NotImplementedException();
        }
        public void ExecuteCommand(int CommandID)
        {
            throw new NotImplementedException();
        }

    }
}
